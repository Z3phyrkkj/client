import Layout from '../components/layout/Layout';
import { motion } from 'framer-motion';
import { Zap, Target, Crosshair, Gauge, Shield, Download } from 'lucide-react';
import Button from '../components/ui/Button';

export default function CheatsBlatant() {
  const features = [
    { icon: Target, title: 'Aimbot Avançado', description: 'Mira automática com customização completa' },
    { icon: Crosshair, title: 'Reach Ilimitado', description: 'Alcance estendido para combate' },
    { icon: Gauge, title: 'Velocity', description: 'Knockback reduzido e movimento otimizado' },
    { icon: Zap, title: 'Fly Mode', description: 'Voo livre em qualquer servidor' },
    { icon: Shield, title: 'Anti-Ban', description: 'Proteção contra detecção automática' },
  ];

  return (
    <Layout>
      <div className="pt-32 pb-20">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <span className="inline-block px-6 py-3 rounded-full bg-gradient-to-r from-[#22d3ee]/20 to-[#a78bfa]/20 border border-[#22d3ee]/30 text-[#22d3ee] text-sm font-semibold mb-6">
              Modo Agressivo
            </span>
            <h1 className="text-6xl font-bold mb-6">
              <span className="gradient-text">Cheats Blatant</span>
            </h1>
            <p className="text-xl text-[var(--text-secondary)] max-w-3xl mx-auto">
              Recursos evidentes e poderosos para dominar qualquer partida. Ideal para servidores com permissão ou modo criativo.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {features.map((feature, i) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: i * 0.1 }}
                  className="card p-8"
                >
                  <Icon size={32} className="text-[#22d3ee] mb-4" />
                  <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                  <p className="text-[var(--text-secondary)]">{feature.description}</p>
                </motion.div>
              );
            })}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="text-center"
          >
            <Button variant="primary" size="large" icon="Download">
              Baixar Cheats Blatant
            </Button>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}
