import Layout from '../components/layout/Layout';
import { motion } from 'framer-motion';
import { BookOpen, PlayCircle, FileText, HelpCircle } from 'lucide-react';

export default function Tutoriais() {
  const tutorials = [
    { icon: PlayCircle, title: 'Instalação Básica', description: 'Como instalar e configurar pela primeira vez' },
    { icon: FileText, title: 'Guias de Configuração', description: 'Ajustes recomendados para cada jogo' },
    { icon: HelpCircle, title: 'FAQ', description: 'Respostas para dúvidas frequentes' },
  ];

  return (
    <Layout>
      <div className="pt-32 pb-20">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <BookOpen size={64} className="text-[#22d3ee] mx-auto mb-6" />
            <h1 className="text-6xl font-bold mb-6">
              <span className="gradient-text">Tutoriais</span>
            </h1>
            <p className="text-xl text-[var(--text-secondary)] max-w-3xl mx-auto">
              Aprenda a usar todas as funcionalidades com nossos guias detalhados.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {tutorials.map((tutorial, i) => {
              const Icon = tutorial.icon;
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: i * 0.1 }}
                  className="card p-8 cursor-pointer"
                >
                  <Icon size={32} className="text-[#22d3ee] mb-4" />
                  <h3 className="text-xl font-bold mb-2">{tutorial.title}</h3>
                  <p className="text-[var(--text-secondary)]">{tutorial.description}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </Layout>
  );
}
