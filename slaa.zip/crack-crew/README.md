# 🎮 Crack Crew

Website profissional para comunidade de gaming com tema de Aurora Boreal.

## ✨ Features

- 🌌 Aurora Boreal realista com partículas e ondas animadas
- 🎨 Design moderno com fontes Orbitron e Exo 2
- 📱 Totalmente responsivo
- ⚡ Animações fluidas com Framer Motion
- 🎯 Ícones profissionais com Lucide React
- 🎨 Paleta de cores Aurora (cyan, teal, purple, pink)

## 🚀 Quick Start

```bash
npm install
npm run dev
```

Abra [http://localhost:3000](http://localhost:3000)

## 📁 Estrutura

```
crack-crew/
├── public/
│   ├── fonts/
│   ├── icons/
│   └── images/
├── src/
│   ├── components/
│   │   ├── layout/
│   │   │   ├── Header.js
│   │   │   ├── Footer.js
│   │   │   └── Layout.js
│   │   ├── ui/
│   │   │   ├── AuroraBackground.js
│   │   │   ├── Button.js
│   │   │   └── Card.js
│   │   └── sections/
│   │       ├── Hero.js
│   │       ├── Features.js
│   │       └── Testimonials.js
│   ├── pages/
│   │   ├── index.js
│   │   ├── cheats-blatant.js
│   │   ├── cheats-legit.js
│   │   ├── cheats-bedrock.js
│   │   ├── auto-clickers.js
│   │   ├── diversos.js
│   │   └── tutoriais.js
│   └── styles/
│       └── globals.css
├── package.json
└── next.config.js
```

## 🎨 Design System

### Cores
- Aurora Cyan: #22d3ee
- Aurora Teal: #14b8a6
- Aurora Purple: #a78bfa
- Aurora Blue: #60a5fa
- Aurora Pink: #f472b6

### Fontes
- Display: Orbitron (Google Fonts)
- Body: Exo 2 (Google Fonts)

## 📦 Tecnologias

- Next.js 14
- React 18
- Framer Motion
- Lucide React
- Google Fonts

## 🌟 Páginas

- Home (Hero, Features, Products, Testimonials, CTA)
- Cheats Blatant
- Cheats Legit
- Cheats Bedrock
- Auto-Clickers
- Diversos
- Tutoriais

## 📄 Licença

Este projeto é apenas para fins educacionais.
