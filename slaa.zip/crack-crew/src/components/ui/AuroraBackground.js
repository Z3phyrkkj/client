import { useEffect, useRef } from 'react';

export default function AuroraBackground() {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    let animationId;
    let particles = [];
    let waves = [];

    const resize = () => {
      const dpr = window.devicePixelRatio || 1;
      canvas.width = window.innerWidth * dpr;
      canvas.height = window.innerHeight * dpr;
      canvas.style.width = `${window.innerWidth}px`;
      canvas.style.height = `${window.innerHeight}px`;
      ctx.scale(dpr, dpr);
    };

    class Particle {
      constructor() {
        this.reset();
      }

      reset() {
        this.x = Math.random() * window.innerWidth;
        this.y = Math.random() * window.innerHeight;
        this.size = Math.random() * 3 + 1;
        this.speedX = (Math.random() - 0.5) * 0.5;
        this.speedY = (Math.random() - 0.5) * 0.5;
        this.opacity = Math.random() * 0.5 + 0.2;
        
        const colors = [
          [167, 139, 250],
          [96, 165, 250],
          [34, 211, 238],
          [20, 184, 166],
          [244, 114, 182],
        ];
        this.color = colors[Math.floor(Math.random() * colors.length)];
      }

      update() {
        this.x += this.speedX;
        this.y += this.speedY;

        if (this.x < 0 || this.x > window.innerWidth) this.speedX *= -1;
        if (this.y < 0 || this.y > window.innerHeight) this.speedY *= -1;
      }

      draw() {
        ctx.beginPath();
        const gradient = ctx.createRadialGradient(this.x, this.y, 0, this.x, this.y, this.size * 3);
        gradient.addColorStop(0, `rgba(${this.color.join(',')}, ${this.opacity})`);
        gradient.addColorStop(1, `rgba(${this.color.join(',')}, 0)`);
        ctx.fillStyle = gradient;
        ctx.arc(this.x, this.y, this.size * 3, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    class Wave {
      constructor(y, speed, amplitude, frequency, color) {
        this.y = y;
        this.speed = speed;
        this.amplitude = amplitude;
        this.frequency = frequency;
        this.color = color;
        this.offset = Math.random() * Math.PI * 2;
      }

      update() {
        this.offset += this.speed;
      }

      draw() {
        ctx.beginPath();
        ctx.moveTo(0, window.innerHeight);

        for (let x = 0; x <= window.innerWidth; x += 5) {
          const y = this.y + Math.sin((x * this.frequency) + this.offset) * this.amplitude;
          if (x === 0) {
            ctx.lineTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }

        ctx.lineTo(window.innerWidth, window.innerHeight);
        ctx.closePath();

        const gradient = ctx.createLinearGradient(0, 0, 0, window.innerHeight);
        gradient.addColorStop(0, `rgba(${this.color.join(',')}, 0)`);
        gradient.addColorStop(0.5, `rgba(${this.color.join(',')}, 0.08)`);
        gradient.addColorStop(1, `rgba(${this.color.join(',')}, 0)`);
        ctx.fillStyle = gradient;
        ctx.fill();
      }
    }

    const init = () => {
      resize();
      
      particles = [];
      for (let i = 0; i < 50; i++) {
        particles.push(new Particle());
      }

      waves = [
        new Wave(window.innerHeight * 0.3, 0.002, 60, 0.003, [167, 139, 250]),
        new Wave(window.innerHeight * 0.4, 0.0015, 80, 0.002, [96, 165, 250]),
        new Wave(window.innerHeight * 0.5, 0.0025, 70, 0.0025, [34, 211, 238]),
        new Wave(window.innerHeight * 0.6, 0.002, 90, 0.002, [20, 184, 166]),
      ];
    };

    const animate = () => {
      ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);

      ctx.fillStyle = 'rgba(10, 14, 26, 0.1)';
      ctx.fillRect(0, 0, window.innerWidth, window.innerHeight);

      waves.forEach(wave => {
        wave.update();
        wave.draw();
      });

      particles.forEach(particle => {
        particle.update();
        particle.draw();
      });

      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const distance = Math.sqrt(dx * dx + dy * dy);

          if (distance < 150) {
            ctx.beginPath();
            ctx.strokeStyle = `rgba(34, 211, 238, ${0.1 * (1 - distance / 150)})`;
            ctx.lineWidth = 0.5;
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
          }
        }
      }

      animationId = requestAnimationFrame(animate);
    };

    init();
    animate();

    window.addEventListener('resize', init);

    return () => {
      window.removeEventListener('resize', init);
      cancelAnimationFrame(animationId);
    };
  }, []);

  return (
    <>
      <canvas
        ref={canvasRef}
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          zIndex: -2,
          pointerEvents: 'none',
        }}
      />
      <div
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          background: 'radial-gradient(ellipse at 50% 30%, rgba(167, 139, 250, 0.15) 0%, transparent 50%), radial-gradient(ellipse at 80% 70%, rgba(34, 211, 238, 0.1) 0%, transparent 50%)',
          zIndex: -1,
          pointerEvents: 'none',
        }}
      />
    </>
  );
}
