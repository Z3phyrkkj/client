import Layout from '../components/layout/Layout';
import { motion } from 'framer-motion';
import { Shield, Eye, Crosshair, Activity, Lock, Download } from 'lucide-react';
import Button from '../components/ui/Button';

export default function CheatsLegit() {
  const features = [
    { icon: Crosshair, title: 'Legit Aimbot', description: 'Mira sutil e realista' },
    { icon: Activity, title: 'Triggerbot', description: 'Disparo automático inteligente' },
    { icon: Eye, title: 'ESP Discreto', description: 'Informações visuais sutis' },
    { icon: Shield, title: 'Anti-Detecção', description: 'Totalmente indetectável' },
    { icon: Lock, title: 'Configs Seguras', description: 'Ajustes pré-configurados' },
  ];

  return (
    <Layout>
      <div className="pt-32 pb-20">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <span className="inline-block px-6 py-3 rounded-full bg-gradient-to-r from-[#14b8a6]/20 to-[#60a5fa]/20 border border-[#14b8a6]/30 text-[#14b8a6] text-sm font-semibold mb-6">
              Modo Discreto
            </span>
            <h1 className="text-6xl font-bold mb-6">
              <span className="gradient-text">Cheats Legit</span>
            </h1>
            <p className="text-xl text-[var(--text-secondary)] max-w-3xl mx-auto">
              Configurações sutis e realistas para jogar competitivamente sem levantar suspeitas. Totalmente indetectável.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {features.map((feature, i) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: i * 0.1 }}
                  className="card p-8"
                >
                  <Icon size={32} className="text-[#14b8a6] mb-4" />
                  <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                  <p className="text-[var(--text-secondary)]">{feature.description}</p>
                </motion.div>
              );
            })}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="text-center"
          >
            <Button variant="primary" size="large" icon="Download">
              Baixar Cheats Legit
            </Button>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}
