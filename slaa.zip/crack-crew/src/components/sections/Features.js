import { motion } from 'framer-motion';
import { Shield, Zap, Users, Settings, Download, Gamepad2 } from 'lucide-react';

export default function Features() {
  const features = [
    {
      icon: Shield,
      title: 'Segurança Avançada',
      description: 'Bypass modernos e atualizações constantes. Mantemos sua conta segura contra detecção.',
      color: '#22d3ee',
    },
    {
      icon: Zap,
      title: 'Performance Otimizada',
      description: 'Código otimizado que não compromete o desempenho do jogo ou do sistema.',
      color: '#14b8a6',
    },
    {
      icon: Users,
      title: 'Comunidade Ativa',
      description: 'Junte-se a milhares de jogadores compartilhando configs e estratégias.',
      color: '#60a5fa',
    },
    {
      icon: Settings,
      title: 'Customização Total',
      description: 'Mais de 50 configurações para ajustar cada detalhe ao seu estilo de jogo.',
      color: '#a78bfa',
    },
    {
      icon: Download,
      title: 'Atualizações Constantes',
      description: 'Novos recursos e correções regularmente para manter você competitivo.',
      color: '#f472b6',
    },
    {
      icon: Gamepad2,
      title: 'Suporte 24/7',
      description: 'Equipe especializada disponível para ajudar a qualquer momento.',
      color: '#22d3ee',
    },
  ];

  return (
    <section id="features" className="section">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-6 py-3 rounded-full bg-gradient-to-r from-[#22d3ee]/20 to-[#a78bfa]/20 border border-[#22d3ee]/30 text-[#22d3ee] text-sm font-semibold mb-6">
            Por que escolher a Crack Crew?
          </span>
          <h2 className="text-5xl font-bold mb-6">
            Tudo o que você precisa em <span className="gradient-text">um só lugar</span>
          </h2>
          <p className="text-xl text-[var(--text-secondary)] max-w-3xl mx-auto">
            Desenvolvemos as ferramentas mais avançadas do mercado com foco em performance, segurança e experiência do usuário.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, i) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                whileHover={{ y: -8 }}
                className="group"
              >
                <div className="card h-full p-8">
                  <div
                    className="inline-flex p-4 rounded-xl mb-6 transition-all duration-300 group-hover:scale-110"
                    style={{
                      background: `${feature.color}20`,
                      border: `1px solid ${feature.color}30`,
                    }}
                  >
                    <Icon size={32} style={{ color: feature.color }} />
                  </div>

                  <h3 className="text-2xl font-bold mb-4" style={{ color: feature.color }}>
                    {feature.title}
                  </h3>

                  <p className="text-[var(--text-secondary)] leading-relaxed">
                    {feature.description}
                  </p>

                  <div className="mt-6 pt-6 border-t border-white/5">
                    <div className="flex items-center gap-2 text-sm text-[var(--text-tertiary)]">
                      <span>Saiba mais</span>
                      <svg className="w-4 h-4 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-20 p-10 rounded-3xl bg-gradient-to-r from-[#22d3ee]/10 via-[#a78bfa]/10 to-[#f472b6]/10 border border-white/10 backdrop-blur-lg"
        >
          <div className="grid md:grid-cols-2 gap-10 items-center">
            <div>
              <h3 className="text-3xl font-bold mb-4">
                <span className="gradient-text">Zero banimentos</span> em servidores com permissão
              </h3>
              <p className="text-[var(--text-secondary)] mb-6">
                Nossa tecnologia de bypass é atualizada diariamente para garantir que você jogue com segurança e sem preocupações.
              </p>
              <div className="flex items-center gap-4">
                <div className="flex -space-x-2">
                  {[...Array(4)].map((_, i) => (
                    <div
                      key={i}
                      className="w-12 h-12 rounded-full border-2 border-[var(--bg-primary)] bg-gradient-to-br from-[#22d3ee] to-[#a78bfa]"
                    />
                  ))}
                </div>
                <div className="text-sm">
                  <div className="font-semibold">+500 jogadores por dia</div>
                  <div className="text-[var(--text-tertiary)]">usando com segurança</div>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {[
                { stat: '99.8%', label: 'Taxa de sucesso' },
                { stat: '24h', label: 'Atualizações' },
                { stat: '0.01%', label: 'Detecção' },
                { stat: '50ms', label: 'Latência' },
              ].map((item, i) => (
                <div
                  key={i}
                  className="p-6 rounded-xl bg-[var(--bg-primary)]/50 border border-white/5 text-center"
                >
                  <div className="text-2xl font-bold gradient-text mb-1">{item.stat}</div>
                  <div className="text-sm text-[var(--text-tertiary)]">{item.label}</div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
