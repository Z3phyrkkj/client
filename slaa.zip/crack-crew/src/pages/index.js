import Layout from '../components/layout/Layout';
import Hero from '../components/sections/Hero';
import Features from '../components/sections/Features';
import Testimonials from '../components/sections/Testimonials';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import { motion } from 'framer-motion';

export default function Home() {
  const products = [
    {
      title: 'Cheats Blatant',
      description: 'Modo agressivo com recursos evidentes para dominar qualquer partida. Perfeito para servidores com permissão.',
      icon: 'Zap',
      color: '#22d3ee',
      tags: ['Aimbot', 'Reach', 'Velocity', 'Fly'],
      price: 'Grátis',
      delay: 0.1,
    },
    {
      title: 'Cheats Legit',
      description: 'Configurações sutis e realistas para jogar competitivamente sem levantar suspeitas. Indetectável.',
      icon: 'Shield',
      color: '#14b8a6',
      tags: ['Legit Aimbot', 'Triggerbot', 'ESP', 'Radar'],
      price: 'R$ 29,90',
      delay: 0.2,
    },
    {
      title: 'Cheats Bedrock',
      description: 'Soluções especializadas para a versão Bedrock do Minecraft. Compatível com Windows, Android e iOS.',
      icon: 'Gamepad2',
      color: '#a78bfa',
      tags: ['X-Ray', 'Speed', 'Reach', 'AutoClicker'],
      price: 'R$ 19,90',
      delay: 0.3,
    },
  ];

  return (
    <Layout>
      <Hero />
      <Features />

      <section className="section">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl font-bold mb-6">
              Nossos <span className="gradient-text">Produtos</span>
            </h2>
            <p className="text-xl text-[var(--text-secondary)] max-w-3xl mx-auto">
              Escolha entre nossa coleção de cheats e utilitários desenvolvidos para oferecer a melhor experiência em jogos.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {products.map((product, i) => (
              <Card
                key={i}
                {...product}
                actionText="Baixar Agora"
                onClick={() => window.location.href = `/${product.title.toLowerCase().replace(' ', '-')}`}
              />
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-center"
          >
            <p className="text-lg text-[var(--text-secondary)] mb-8 max-w-2xl mx-auto">
              Todos os nossos produtos incluem atualizações gratuitas, suporte 24/7 e garantia de segurança. Ainda em dúvida?
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Button variant="secondary" size="large" onClick={() => window.location.href = '/tutoriais'}>
                Ver Tutoriais
              </Button>
              <Button variant="primary" size="large" icon="Download" onClick={() => window.location.href = '/#download'}>
                Experimentar Grátis
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      <Testimonials />

      <section id="download" className="section">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="max-w-4xl mx-auto text-center p-12 rounded-3xl relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-[#22d3ee]/10 via-[#a78bfa]/10 to-[#f472b6]/10" />
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(34,211,238,0.15),transparent_50%)]" />
            <div className="absolute inset-0 border border-white/10 rounded-3xl" />

            <div className="relative z-10">
              <h2 className="text-5xl font-bold mb-6">
                Pronto para <span className="gradient-text">elevar seu jogo</span>?
              </h2>
              <p className="text-xl text-[var(--text-secondary)] mb-10 max-w-2xl mx-auto">
                Junte-se a milhares de jogadores que já estão dominando com a Crack Crew. Baixe agora e experimente grátis por 7 dias!
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  variant="primary"
                  size="large"
                  icon="Download"
                  onClick={() => alert('Iniciando download... (versão demo)')}
                >
                  Baixar Agora (100MB)
                </Button>
                <Button
                  variant="secondary"
                  size="large"
                  onClick={() => window.location.href = '/tutoriais#instalacao'}
                >
                  Ver Instruções
                </Button>
              </div>

              <div className="mt-8 flex items-center justify-center gap-2 text-sm text-[var(--text-tertiary)]">
                <div className="w-2 h-2 rounded-full bg-green-500" />
                <span>Seguro • Sem vírus • Atualizado hoje</span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
}
