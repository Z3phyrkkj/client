import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';

export default function Testimonials() {
  const testimonials = [
    {
      id: 1,
      name: 'Rafael "Strike" Silva',
      role: 'Player Profissional',
      content: 'Os cheats da Crack Crew elevaram meu jogo a outro nível. O sistema de aimbot é o mais suave que já usei, e o suporte responde em minutos!',
      rating: 5,
      color: '#22d3ee',
    },
    {
      id: 2,
      name: 'Juliana "Shadow" Costa',
      role: 'Streamer',
      content: 'Como streamer, preciso de ferramentas confiáveis e discretas. Os cheats legit da Crack Crew são perfeitos - ninguém percebe, mas minha performance melhorou 300%.',
      rating: 5,
      color: '#14b8a6',
    },
    {
      id: 3,
      name: 'Marcos "Viper" Oliveira',
      role: 'Competidor',
      content: 'Já testei diversas soluções no mercado, mas a Crack Crew se destaca pela estabilidade e atualizações constantes. Nunca fui banido em 6 meses de uso.',
      rating: 5,
      color: '#a78bfa',
    },
    {
      id: 4,
      name: 'Ana "Spectre" Santos',
      role: 'Clutch Player',
      content: 'O auto-clicker da Crack Crew é simplesmente o melhor. Configuração intuitiva e performance impecável. Recomendo para todos os jogadores competitivos.',
      rating: 5,
      color: '#60a5fa',
    },
  ];

  const [currentIndex, setCurrentIndex] = useState(0);
  const [autoplay, setAutoplay] = useState(true);

  useEffect(() => {
    if (!autoplay) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [autoplay, testimonials.length]);

  const next = () => setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  const prev = () => setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);

  return (
    <section className="section bg-gradient-to-b from-transparent to-[rgba(10,10,26,0.4)]">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl font-bold mb-6">
            O que dizem nossos <span className="gradient-text">clientes</span>
          </h2>
          <p className="text-xl text-[var(--text-secondary)] max-w-3xl mx-auto">
            Junte-se a milhares de jogadores que já transformaram sua experiência com a Crack Crew.
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto" onMouseEnter={() => setAutoplay(false)} onMouseLeave={() => setAutoplay(true)}>
          <div className="flex items-center gap-6">
            <motion.button
              className="w-14 h-14 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-[#22d3ee] hover:bg-white/10 flex-shrink-0"
              onClick={prev}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <ChevronLeft size={24} />
            </motion.button>

            <div className="flex-1 min-h-[320px]">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentIndex}
                  initial={{ opacity: 0, x: 100 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -100 }}
                  transition={{ duration: 0.4 }}
                  className="card p-10"
                >
                  <div className="mb-6">
                    <div className="text-6xl font-serif mb-4 opacity-20" style={{ color: testimonials[currentIndex].color }}>
                      "
                    </div>
                    <p className="text-lg leading-relaxed text-[var(--text-primary)] italic">
                      {testimonials[currentIndex].content}
                    </p>

                    <div className="flex gap-1 mt-6">
                      {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                        <Star key={i} size={20} fill={testimonials[currentIndex].color} style={{ color: testimonials[currentIndex].color }} />
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center gap-4 pt-6 border-t border-white/10">
                    <div className="w-16 h-16 rounded-full flex items-center justify-center text-2xl" style={{ background: testimonials[currentIndex].color }}>
                      {testimonials[currentIndex].name[0]}
                    </div>
                    <div>
                      <h4 className="text-lg font-bold">{testimonials[currentIndex].name}</h4>
                      <p className="text-[var(--text-tertiary)]">{testimonials[currentIndex].role}</p>
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>

            <motion.button
              className="w-14 h-14 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-[#22d3ee] hover:bg-white/10 flex-shrink-0"
              onClick={next}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <ChevronRight size={24} />
            </motion.button>
          </div>

          <div className="flex justify-center gap-3 mt-8">
            {testimonials.map((_, i) => (
              <button
                key={i}
                className="w-3 h-3 rounded-full transition-all"
                onClick={() => setCurrentIndex(i)}
                style={{
                  background: i === currentIndex ? testimonials[currentIndex].color : 'rgba(255, 255, 255, 0.2)',
                  transform: i === currentIndex ? 'scale(1.3)' : 'scale(1)',
                }}
              />
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="flex justify-center gap-10 mt-16 flex-wrap"
        >
          {[
            { icon: '✓', number: '4.9/5', label: 'Avaliações' },
            { icon: '👥', number: '10K+', label: 'Comunidade' },
            { icon: '🛡️', number: '99.8%', label: 'Taxa de Segurança' },
          ].map((badge, i) => (
            <div key={i} className="flex items-center gap-4 px-8 py-5 bg-white/3 rounded-2xl border border-white/5 hover:bg-white/5 transition-all">
              <div className="text-3xl">{badge.icon}</div>
              <div>
                <div className="text-2xl font-bold gradient-text">{badge.number}</div>
                <div className="text-sm text-[var(--text-tertiary)]">{badge.label}</div>
              </div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
