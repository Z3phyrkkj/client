import { motion } from 'framer-motion';
import * as Icons from 'lucide-react';

export default function Button({ 
  children, 
  variant = 'primary', 
  size = 'medium',
  icon,
  iconPosition = 'left',
  loading = false,
  disabled = false,
  fullWidth = false,
  className = '',
  onClick,
  ...props 
}) {
  const sizes = {
    small: 'px-4 py-2 text-sm',
    medium: 'px-8 py-3.5 text-base',
    large: 'px-10 py-4 text-lg',
  };

  const variants = {
    primary: 'btn-primary',
    secondary: 'btn-secondary',
  };

  const iconSizes = {
    small: 16,
    medium: 20,
    large: 24,
  };

  const IconComponent = icon ? Icons[icon] : null;

  return (
    <motion.button
      className={`btn ${variants[variant]} ${sizes[size]} ${fullWidth ? 'w-full' : ''} ${className}`}
      whileHover={!disabled && !loading ? { scale: 1.02 } : {}}
      whileTap={!disabled && !loading ? { scale: 0.98 } : {}}
      disabled={disabled || loading}
      onClick={onClick}
      {...props}
    >
      {loading ? (
        <Icons.Loader2 className="animate-spin" size={iconSizes[size]} />
      ) : (
        <>
          {IconComponent && iconPosition === 'left' && (
            <IconComponent size={iconSizes[size]} />
          )}
          {children}
          {IconComponent && iconPosition === 'right' && (
            <IconComponent size={iconSizes[size]} />
          )}
        </>
      )}
    </motion.button>
  );
}
