import Link from 'next/link';
import { motion } from 'framer-motion';
import { Github, MessageCircle, Youtube, Send } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const socialLinks = [
    { icon: MessageCircle, href: '#', label: 'Discord' },
    { icon: Send, href: '#', label: 'Telegram' },
    { icon: Youtube, href: '#', label: 'YouTube' },
    { icon: Github, href: '#', label: 'GitHub' },
  ];

  const pageLinks = [
    { name: 'Home', href: '/' },
    { name: 'Cheats Blatant', href: '/cheats-blatant' },
    { name: 'Cheats Legit', href: '/cheats-legit' },
    { name: 'Cheats Bedrock', href: '/cheats-bedrock' },
    { name: 'Auto-Clickers', href: '/auto-clickers' },
    { name: 'Diversos', href: '/diversos' },
    { name: 'Tutoriais', href: '/tutoriais' },
  ];

  const supportLinks = [
    { name: 'FAQ', href: '/faq' },
    { name: 'Contato', href: '/contato' },
    { name: 'Termos de Uso', href: '/termos' },
    { name: 'Política de Privacidade', href: '/privacidade' },
  ];

  return (
    <footer className="relative border-t border-white/5" style={{ background: 'rgba(5, 5, 17, 0.95)' }}>
      <div className="container py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          <div>
            <motion.div
              className="flex items-center gap-2 mb-6"
              whileHover={{ scale: 1.05 }}
            >
              <span className="text-3xl font-bold">
                <span className="text-[#22d3ee]">CRACK</span>
                <span className="text-[#a78bfa]">CREW</span>
              </span>
            </motion.div>
            <p className="text-[var(--text-secondary)] leading-relaxed mb-6">
              A maior comunidade de cheats e utilitários para jogos. Oferecemos soluções premium com segurança e performance.
            </p>
            <div className="flex gap-4">
              {socialLinks.map(({ icon: Icon, href, label }) => (
                <motion.a
                  key={label}
                  href={href}
                  className="w-12 h-12 rounded-full flex items-center justify-center bg-white/5 border border-white/10 text-[#22d3ee]"
                  whileHover={{ scale: 1.2, y: -5, backgroundColor: '#22d3ee', color: '#0a0e1a' }}
                  whileTap={{ scale: 0.9 }}
                  aria-label={label}
                >
                  <Icon size={20} />
                </motion.a>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-6 text-[#22d3ee]">Páginas</h3>
            <ul className="space-y-3">
              {pageLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-[var(--text-secondary)] hover:text-[#22d3ee] hover:translate-x-1 inline-block transition-all"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-6 text-[#22d3ee]">Suporte</h3>
            <ul className="space-y-3">
              {supportLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-[var(--text-secondary)] hover:text-[#22d3ee] hover:translate-x-1 inline-block transition-all"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-white/5 text-center space-y-2">
          <p className="text-[var(--text-tertiary)] text-sm">
            © {currentYear} Crack Crew. Todos os direitos reservados.
          </p>
          <p className="text-[var(--text-tertiary)] text-sm">
            Este site é apenas para fins educacionais.
          </p>
        </div>
      </div>
    </footer>
  );
}
