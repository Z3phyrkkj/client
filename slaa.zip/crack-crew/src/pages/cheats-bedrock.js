import Layout from '../components/layout/Layout';
import { motion } from 'framer-motion';
import { Gamepad2, Smartphone, Monitor, Zap, Download } from 'lucide-react';
import Button from '../components/ui/Button';

export default function CheatsBedrock() {
  const features = [
    { icon: Monitor, title: 'Windows', description: 'Compatível com Windows 10/11' },
    { icon: Smartphone, title: 'Android', description: 'Funciona em Android 8+' },
    { icon: Gamepad2, title: 'iOS', description: 'Suporte para iPhone/iPad' },
    { icon: Zap, title: 'X-Ray', description: 'Veja minérios através de blocos' },
  ];

  return (
    <Layout>
      <div className="pt-32 pb-20">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <span className="inline-block px-6 py-3 rounded-full bg-gradient-to-r from-[#a78bfa]/20 to-[#f472b6]/20 border border-[#a78bfa]/30 text-[#a78bfa] text-sm font-semibold mb-6">
              Multiplataforma
            </span>
            <h1 className="text-6xl font-bold mb-6">
              <span className="gradient-text">Cheats Bedrock</span>
            </h1>
            <p className="text-xl text-[var(--text-secondary)] max-w-3xl mx-auto">
              Soluções especializadas para Minecraft Bedrock. Compatível com Windows, Android e iOS.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            {features.map((feature, i) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: i * 0.1 }}
                  className="card p-8"
                >
                  <Icon size={32} className="text-[#a78bfa] mb-4" />
                  <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                  <p className="text-[var(--text-secondary)]">{feature.description}</p>
                </motion.div>
              );
            })}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="text-center"
          >
            <Button variant="primary" size="large" icon="Download">
              Baixar Cheats Bedrock
            </Button>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}
