import { motion } from 'framer-motion';
import * as Icons from 'lucide-react';

export default function Card({ 
  title,
  description,
  icon,
  color = '#22d3ee',
  tags = [],
  price,
  actionText,
  onClick,
  delay = 0,
}) {
  const IconComponent = Icons[icon];

  return (
    <motion.div
      className="card p-8 h-full flex flex-col cursor-pointer"
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay }}
      whileHover={{ y: -10 }}
      onClick={onClick}
    >
      <div className="flex items-start gap-4 mb-6">
        {IconComponent && (
          <div 
            className="p-4 rounded-xl flex-shrink-0"
            style={{ 
              background: `${color}20`,
              border: `1px solid ${color}40`,
            }}
          >
            <IconComponent size={32} style={{ color }} />
          </div>
        )}
        <div className="flex-1">
          <h3 className="text-2xl font-bold mb-3" style={{ color }}>
            {title}
          </h3>
          <p className="text-base leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
            {description}
          </p>
        </div>
      </div>

      {tags.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-6">
          {tags.map((tag, i) => (
            <span
              key={i}
              className="px-3 py-1.5 text-xs rounded-lg font-medium"
              style={{ 
                background: `${color}15`,
                color: color,
                border: `1px solid ${color}30`,
              }}
            >
              {tag}
            </span>
          ))}
        </div>
      )}

      <div className="flex items-center justify-between mt-auto pt-6 border-t" style={{ borderColor: 'rgba(255, 255, 255, 0.05)' }}>
        {price && (
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold" style={{ color }}>
              {price}
            </span>
            {price !== 'Grátis' && (
              <span className="text-sm" style={{ color: 'var(--text-tertiary)' }}>/mês</span>
            )}
          </div>
        )}
        
        {actionText && (
          <motion.button
            className="px-6 py-3 rounded-lg font-semibold text-sm"
            style={{ 
              background: color,
              color: 'var(--bg-primary)',
            }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={(e) => {
              e.stopPropagation();
              onClick?.();
            }}
          >
            {actionText}
          </motion.button>
        )}
      </div>
    </motion.div>
  );
}
