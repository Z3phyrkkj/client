import Layout from '../components/layout/Layout';
import { motion } from 'framer-motion';
import { Package, Download } from 'lucide-react';
import Button from '../components/ui/Button';

export default function Diversos() {
  return (
    <Layout>
      <div className="pt-32 pb-20">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <Package size={64} className="text-[#22d3ee] mx-auto mb-6" />
            <h1 className="text-6xl font-bold mb-6">
              <span className="gradient-text">Diversos</span>
            </h1>
            <p className="text-xl text-[var(--text-secondary)] max-w-3xl mx-auto mb-12">
              Utilitários e ferramentas adicionais para melhorar sua experiência de jogo.
            </p>
            <Button variant="primary" size="large" icon="Download">
              Ver Mais Ferramentas
            </Button>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}
