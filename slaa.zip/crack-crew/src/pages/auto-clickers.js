import Layout from '../components/layout/Layout';
import { motion } from 'framer-motion';
import { MousePointer2, Download } from 'lucide-react';
import Button from '../components/ui/Button';

export default function AutoClickers() {
  return (
    <Layout>
      <div className="pt-32 pb-20">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <MousePointer2 size={64} className="text-[#22d3ee] mx-auto mb-6" />
            <h1 className="text-6xl font-bold mb-6">
              <span className="gradient-text">Auto-Clickers</span>
            </h1>
            <p className="text-xl text-[var(--text-secondary)] max-w-3xl mx-auto mb-12">
              Ferramentas de clique automático para otimizar sua performance em jogos.
            </p>
            <Button variant="primary" size="large" icon="Download">
              Baixar Auto-Clickers
            </Button>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}
