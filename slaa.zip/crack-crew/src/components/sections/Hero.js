import { motion } from 'framer-motion';
import { Download, Zap, Users, Star, Settings } from 'lucide-react';
import Button from '../ui/Button';

export default function Hero() {
  const stats = [
    { value: '10K+', label: 'Usuários Ativos', icon: Users },
    { value: '99.8%', label: 'Satisfação', icon: Star },
    { value: '24/7', label: 'Suporte', icon: Settings },
    { value: '50+', label: 'Recursos', icon: Zap },
  ];

  return (
    <section className="relative min-h-screen flex items-center pt-32 pb-20">
      <div className="absolute inset-0 z-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#22d3ee]/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#a78bfa]/10 rounded-full blur-3xl" />
      </div>

      <div className="container relative z-10">
        <div className="max-w-5xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-[#22d3ee]/20 to-[#a78bfa]/20 border border-[#22d3ee]/30 mb-8"
          >
            <Star size={18} className="text-[#22d3ee]" />
            <span className="text-sm font-semibold text-[#22d3ee]">
              A Elite dos Cheats para Jogos
            </span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-6xl md:text-7xl lg:text-8xl font-bold mb-8 leading-tight"
          >
            <span className="block">Domine qualquer</span>
            <span className="gradient-text">jogo como um pro</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-xl md:text-2xl text-[var(--text-secondary)] mb-12 max-w-3xl mx-auto leading-relaxed"
          >
            A maior comunidade de cheats e utilitários para jogos. Soluções premium com segurança, performance e suporte especializado.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="flex flex-col sm:flex-row gap-4 justify-center mb-20"
          >
            <Button variant="primary" size="large" icon="Download" onClick={() => window.location.href = '/#download'}>
              Baixar Agora
            </Button>
            <Button variant="secondary" size="large" icon="Zap" onClick={() => window.location.href = '/#features'}>
              Ver Recursos
            </Button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto"
          >
            {stats.map(({ value, label, icon: Icon }, i) => (
              <div key={i} className="card p-6">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Icon size={20} className="text-[#22d3ee]" />
                  <div className="text-3xl font-bold gradient-text">{value}</div>
                </div>
                <div className="text-sm text-[var(--text-secondary)]">{label}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: 1 }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
      >
        <div className="flex flex-col items-center gap-2">
          <span className="text-sm text-[var(--text-secondary)]">Scroll para explorar</span>
          <div className="w-6 h-10 border-2 border-[#22d3ee]/30 rounded-full flex justify-center">
            <motion.div
              className="w-1.5 h-3 bg-[#22d3ee] rounded-full mt-2"
              animate={{ y: [0, 12, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            />
          </div>
        </div>
      </motion.div>
    </section>
  );
}
