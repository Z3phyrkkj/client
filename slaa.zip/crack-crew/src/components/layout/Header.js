import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { motion, AnimatePresence } from 'framer-motion';
import { Download, Menu, X } from 'lucide-react';
import Button from '../ui/Button';

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const router = useRouter();

  const navItems = [
    { name: 'Home', path: '/' },
    { name: 'Cheats Blatant', path: '/cheats-blatant' },
    { name: 'Cheats Legit', path: '/cheats-legit' },
    { name: 'Cheats Bedrock', path: '/cheats-bedrock' },
    { name: 'Auto-Clickers', path: '/auto-clickers' },
    { name: 'Diversos', path: '/diversos' },
    { name: 'Tutoriais', path: '/tutoriais' },
  ];

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = mobileMenuOpen ? 'hidden' : 'unset';
  }, [mobileMenuOpen]);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'py-4 bg-[rgba(10,14,26,0.95)] backdrop-blur-xl border-b border-white/5' : 'py-6 bg-transparent'
      }`}
    >
      <div className="container flex items-center justify-between">
        <Link href="/">
          <motion.div
            className="flex items-center gap-3 cursor-pointer"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-[#22d3ee] to-[#a78bfa] blur-xl opacity-40" />
              <div className="relative px-5 py-2 rounded-xl bg-[rgba(20,26,40,0.9)] border border-white/10">
                <span className="text-2xl font-bold tracking-tight">
                  <span className="text-[#22d3ee]">CRACK</span>
                  <span className="text-[#a78bfa]">CREW</span>
                </span>
              </div>
            </div>
          </motion.div>
        </Link>

        <nav className="hidden lg:flex items-center gap-8">
          {navItems.map((item) => (
            <Link
              key={item.name}
              href={item.path}
              className={`relative text-sm font-medium transition-colors ${
                router.pathname === item.path ? 'text-[#22d3ee]' : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
            >
              {router.pathname === item.path && (
                <motion.span
                  className="absolute -bottom-1 left-0 right-0 h-0.5 bg-gradient-to-r from-[#22d3ee] to-[#a78bfa]"
                  layoutId="navbar-indicator"
                />
              )}
              {item.name}
            </Link>
          ))}
        </nav>

        <div className="hidden lg:block">
          <Button variant="primary" icon="Download" onClick={() => router.push('/#download')}>
            Baixar Agora
          </Button>
        </div>

        <button
          className="lg:hidden flex flex-col gap-1.5 z-50"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          aria-label="Toggle menu"
        >
          {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="lg:hidden fixed top-[80px] left-0 right-0 bg-[rgba(10,14,26,0.98)] backdrop-blur-xl border-t border-white/5"
          >
            <div className="container py-6">
              <div className="flex flex-col gap-4">
                {navItems.map((item) => (
                  <Link
                    key={item.name}
                    href={item.path}
                    className={`py-3 px-4 rounded-lg text-base font-medium transition-all ${
                      router.pathname === item.path
                        ? 'bg-gradient-to-r from-[#22d3ee]/20 to-[#a78bfa]/20 text-[#22d3ee] border border-[#22d3ee]/30'
                        : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-white/5'
                    }`}
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    {item.name}
                  </Link>
                ))}
                <div className="pt-4 mt-2 border-t border-white/10">
                  <Button
                    variant="primary"
                    fullWidth
                    icon="Download"
                    onClick={() => {
                      router.push('/#download');
                      setMobileMenuOpen(false);
                    }}
                  >
                    Baixar Agora
                  </Button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
